# Maker brief: new clocks for the clock gallery

You are one of several makers each writing about **20 new clocks** for an existing single-file HTML gallery of
animated timepieces (`REGISTER.md` lists them all, with the current count). The page shows every
clock as a square canvas card in a grid, in a random order on each load; clicking a card opens a large "spotlight"
view with the clock beside its explanatory text. The existing clocks are of very high quality — each is a small,
beautifully rendered museum piece with a distinct material, palette and lighting, a precise way of reading the time,
and accurate, engaging history/science text. **Your clocks must match that bar.**

Your orchestrator will tell you: the absolute path of the build directory (called `BUILD` below), your part file
name (`parts/partNN.js`), your scratch folder (called `SCRATCH` below), and your assignment (a batch in
`BUILD/ASSIGN.md`: ids, titles, categories, concepts, looks, reading requirements). Shell variables and `cd` don't
persist between Bash calls: write paths out in full and start tool commands with `cd BUILD && …`.

## Before you write

- Read `BUILD/core.js` fully (~320 lines): the registry, the time object and the helper library `U`.
- Read several existing clocks in `BUILD/parts/` to calibrate quality, structure and caching. Good exemplars:
  `tourbillon`, `nixie`, `wadokei`, `maze`, `sundial`, `english-grid`, `hanoi`, `tetris`, `boids` (parts 1–9),
  and from later rounds `qr-code`, `planetary-gears`, `japanese-readings`, `physarum`, `girih`, `ferrofluid`,
  `teletext`, `rotor-cipher`, `paper-cut`, `kepler-areas`, `danish-numbers`, `nim`.
  (`grep -n "id: 'tourbillon'" BUILD/parts/*.js` finds them.)
- Skim `BUILD/REGISTER.md` so your designs don't echo existing ones in look or mechanism.

## The API

Your file is plain JavaScript loaded after `core.js`. Its first line is the marker comment and **everything** is
wrapped in one IIFE so nothing leaks:

```js
/* ===== partNN.js ===== */
(() => {
  'use strict';
  const { TAU, PI, clamp, lerp, mod, pad2, font, rng, handAngle, polar } = U;
  // ...private helpers (copy small helpers such as layer()/blit() from existing parts as needed)...
  defineClock({ ... });
  defineClock({ ... });
})();
```

The marker line `/* ===== partNN.js ===== */` must be exactly that (the build tools split and assemble on it).
Never write the character sequence `</script` anywhere in the file (split it as `'<\/script'` if needed).

`defineClock({ id, title, category, blurb, read, about, fps?, init?, draw })` — **`id` must be the first property**
(the build tools find clocks by `defineClock({ id: '…'`).

- `id` — kebab-case, unique across the whole gallery. **Use exactly the ids assigned to you.**
- `title` — short display title, Title Case, as in the existing clocks.
- `category` — a key of `CATEGORIES` in core.js (currently `automata`, `history`, `words`, `mechanical`, `cosmic`,
  `math`, `games`, `everyday`, `art`, unless the orchestrator added more). Your assignment says which.
- `blurb` — one sentence (≤ ~30 words) for the hover tooltip; evocative and specific.
- `read` — "How to read it": HTML (`<p>`, `<b>`, `<em>`, `<code>`, `<sub>`, `<sup>`). It must let a newcomer read
  hours, minutes and (where shown) seconds exactly, including edge cases (midnight/noon, AM/PM, zero).
- `about` — "How it works": 2–3 `<p>` paragraphs: real history, mechanism, mathematics or science behind the idea,
  with accurate names and dates; then what this rendering simulates faithfully and what it stylises or invents.
  **Accuracy matters more than colour: if you are not sure of a fact, leave it out.** Check facts with
  WebSearch/WebFetch. Keep it ≤ ~250 words. Write text and data in your own words and from your own working; don't
  download published graphics or data files and copy them into the part (in round 3 two maker runs ended in API
  content-filter errors after doing so).
- `fps` — optional cap (default 60). Use 20–30 for slowly changing clocks; 60 for smooth fast motion.
- `init(W, H, T)` → state object. Called on creation, on every resize, **and again whenever a card scrolls back
  into range after the gallery released it to save memory**. So: build static artwork into offscreen layers here,
  keep it reasonably quick (aim < 30 ms at 460 px), have no side effects outside the returned state, and never assume
  the state survives — it may be discarded at any time and rebuilt.
- `draw(g, W, H, T, S)` — paint the **entire** W×H square every call (never rely on previous frame contents of `g`).
  `g` is already scaled for device pixel ratio; draw in CSS pixels.

The time object `T` (see `makeTime` in core.js): `ms, date, h, m, s, msec, sf (fractional seconds), mf, hf,
h12, pm, daySec, dayFrac, year, month (0-based), day, dow, doy, real (animation seconds, frozen when paused),
speed, paused, dt (seconds since this instance's last draw, 0 when paused, ≤ 0.1), vdt, jump`.
`T.jump` is true on the first frame after init and whenever virtual time jumps (scrubbing, speed change, wake).

The gallery's controls let the viewer pause, scrub ±12 h and run at 1×–3600×. Therefore:
- **The displayed time must always be correct.** Derive the display from `T` (h/m/s/sf…), never from an internal
  counter. Simulations (automata, physics, agents) may run on `T.dt`, but must re-seed / snap to the correct state when
  `T.jump` is true or when they cannot keep up (at 3600× the minute changes every frame — the clock must still show
  the right hour and minute). Freeze motion when `T.dt === 0`.
- Seeded randomness only (`U.rng(seed)`, `U.hash(n)`), seeded from the time where appropriate, so a given time always
  looks the same. Never use `Math.random()` for anything that affects the reading.
- **The time must be readable at every instant.** Transitions at a change should be short: aim for ≤ 1 s, never more
  than ~3 s, and the old value must not linger looking like the current one.

## Helper library `U` (core.js)

`TAU, PI, rad, clamp(x,a,b), lerp, fract, mod, smooth(e0,e1,x), pad2, rng(seed)→()=>[0,1), hash(n)`,
`font(px, fam='sans', weight=400, style='')` with fam `'sans'|'serif'|'mono'|'cjk'|'cjksans'|'korean'` or any CSS family list,
`hsl, rgba, handAngle(frac)` (0 at 12 o'clock, clockwise), `polar(cx,cy,r,ang)→[x,y]`,
`roundRect(g,x,y,w,h,r)` (builds a path), `hand(g,cx,cy,ang,len,width,color,tail,cap)`, `offscreen(w,h)`, `timeStr(T)`,
bitmap fonts `F5x7, F3x5, bitmapText(str,'5x7'|'3x5',spacing)→{w,h,cells,on(x,y)}`,
seven-segment `SEG7, seg7(g,x,y,w,h,digit,on,off,{thick,skew,gap,mask})`,
astronomy for the viewer's approximate location `LOC {lat,lon,tz}` (estimated from the time zone),
`sunPos(ms)→{alt,az(from south, west+),dec,ra,H,eclLon}`,
`sunTimes(ms,lat,lon,altDeg)→{rise,noon,set (local fractional hours),riseMs,noonMs,setMs,polar}`,
`moon(ms)→{phase 0..1,age,illum}`, `lst(ms,lon)` (local sidereal hours), `equationOfTime(ms)` (minutes), `SYNODIC`,
`ease {inOut,out,in,outBack,outElastic}`, `vignette(g,W,H,strength,color)`.
Globals you may read: `CATEGORIES`, `CLOCKS` (don't modify). Don't modify core.js or any other part file.

## Design and quality bar

- **A distinct aesthetic per clock**: a considered material world (enamel, brass, paper, glass, wood, lacquer, CRT
  phosphor, chalk, felt…), palette and lighting, with depth (shadows, highlights, texture, a subtle vignette). Not flat
  generic UI. No two of your clocks should look alike, and none should duplicate an existing one in the register.
- The card is square and fills the whole canvas (paint a full background). Use `s = Math.min(W, H)` for scaling.
- **Legible at both 140 px (gallery card) and ~460–800 px (spotlight).** At small sizes drop fine detail
  (e.g. `if (s < 170)` fewer ticks/labels, bigger key numerals); at large sizes reward the eye with detail.
  A clock whose time can't be read on the 140 px card is not finished. Round 3's commonest send-backs were readings
  that need *counting* (pegs, beads, lamps, garments) or *small dials* tucked into a scene: at card size, enlarge the
  counters, number the positions, or add a clear numeral that belongs to the object (a tag, a plate, a readout).
  Digits built from many small parts (mines, map countries, pipe tiles) must still read unmistakably as digits.
- **Performance** (the page draws up to ~50 clocks at once, software-rendered on some machines):
  cache all static art in offscreen layers built in `init` (sized by devicePixelRatio, capped at 2.5 — copy the
  `layer()` helper pattern from existing parts), redraw dynamic parts only, and rebuild cached layers only when their
  content changes (e.g. once per second/minute). Avoid per frame: `shadowBlur`, hundreds of gradient objects,
  large `getImageData/putImageData`, `filter`, and text measurement in loops (cache it). Harness targets:
  **avg < 3 ms at 140 px and < 12 ms at 460 px** (it flags SLOW above that). Heavy pixel work (fractals, chaos games,
  reaction–diffusion) must be incremental or cached. If you read pixels back with `getImageData` more than once from
  the same canvas (e.g. a glyph mask rebuilt each second or minute), create its context with
  `getContext('2d', { willReadFrequently: true })` — otherwise Chrome logs a warning that the page test counts as an error.
- Fonts: system font stacks only via `U.font` or explicit CSS stacks; no web fonts, images, network or libraries.
  Non-Latin scripts need stacks that macOS/Windows have (Thai: `"Thonburi","Leelawadee UI","Tahoma"`; Arabic:
  `"Geeza Pro","Segoe UI","Arial"`; Hebrew: `"Arial Hebrew","Segoe UI","Arial"`; Devanagari: `"Kohinoor Devanagari",
  "Nirmala UI"`), ending with a generic family. Where a script may be missing from users' machines (rare numerals,
  hieroglyphs, runes…) **draw the glyphs procedurally**. The test machine's fonts (FreeSerif, DejaVu, Noto CJK,
  IPAGothic, Unifont) differ from users', so judge typography with that in mind.
- **No intellectual-property reproduction**: no trademarked or branded designs, logos, mascots or recognisable game
  characters (original pixel creatures, not famous sprites; a generic look, not a brand's trade dress); no song lyrics
  or copyrighted text; no copying of a specific artwork — evoke a movement or craft instead. Titles are generic.
- **Linguistic accuracy is paramount** (the gallery's owner is a professional lexicographer and Japanese–English
  translator): write explicit number-word/phrase functions, run them over all 1,440 minutes in a quick node script,
  read the output, and verify uncertain conventions. Where usage varies, choose one and say so in `about`.
- Text style: British spelling as in the existing clocks ("colour", "numerals"); typographic quotes ’ “ ”; en/em
  dashes; real units. The 24-hour clock is the default unless the concept implies otherwise; state the convention in `read`.
- Invented reading conventions are fine (they are often necessary) but must be stated honestly in `read`/`about`.

## Testing (required)

Run from `BUILD` (`cd BUILD && …`):
```
node tools/test.mjs parts/partNN.js --out SCRATCH/shots      # add --ids a,b to test a subset; --tz Europe/London etc.
node tools/snap.mjs parts/partNN.js SCRATCH/snaps 300 my-id@23:59:59 my-id@00:00:01@2026-03-03   # chosen times (+0.5 s); --tz too
python3 tools/sheet.py SCRATCH/shots L1 SCRATCH/sheet          # contact sheet of all your L1 snapshots
```
`test.mjs` runs every clock in the part through running time, jumps, midnight/noon crossings, 3600× fast-forward and
pause, at 140 px and 460 px (device pixel ratio 2), checks the required fields, reports exceptions and draw cost, and
writes `<id>_L1.png` (14:37:24 on 16 Oct 2026, 460 px), `<id>_L2.png` (09:06:00, just after a minute rollover, 460 px)
and `<id>_S.png` (14:37:24, 140 px). Timezone defaults to Asia/Tokyo.

**Look at every snapshot with the Read tool** and confirm (1) it looks polished and intentional, (2) the time is
readable and *correct* in the picture, (3) the 140 px version is legible. Use `snap.mjs` to check awkward times
(midnight, noon, x:00, x:15, x:45, x:59, ~1 s after a minute change) — especially for word and numeral clocks.
Timings are inflated several-fold when other makers' browsers run at the same time; if a clock is flagged SLOW, re-run
it alone before optimising. Iterate until every clock has zero errors, none is SLOW, and you are proud of every snapshot.
Use only your own scratch folder. Write the part in stages (a few clocks at a time, testing as you go).

## When done

Reply briefly with: the ids/titles delivered, the final harness lines, and caveats (simplifications, invented
conventions, facts you omitted as unverified, font fallbacks, transitions longer than 1 s).
