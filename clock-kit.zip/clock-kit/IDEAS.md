# Idea reservoir

Unbuilt concepts for future rounds, grouped loosely by category. Each is a one-line seed, not a design: the
orchestrator develops the look and the exact reading scheme when assigning it. Before using an idea, check
`REGISTER.md` for overlap — seeds marked ⚠ name the existing clock they risk echoing, and need a clearly different
mechanism and look. After using an idea, delete it here. Add new ideas whenever they occur.
Suggested ids are only suggestions.

## Historical and cultural timekeeping (`history`)
- `zmanim` — Jewish halakhic hours (shaʿot zmaniyot) from today's sunrise and sunset, on a sofer's scroll layout.
- `geez-numerals` — Ethiopian time (counted from 6 a.m.) written in Geʽez numerals, drawn procedurally. ⚠ close to `swahili-time` (same 6 a.m. count)
- `watchmans-clock` — a night watchman's tour recorder: keys at stations punch a paper dial.
- `oil-lamp` — a graduated pewter oil-lamp clock whose falling oil level marks the hours. ⚠ close to `candle-clock`
- `fusee` — a verge bracket clock with its chain fusee visibly unwinding through the day.
- `nilometer` — a graduated Nilometer staircase whose water level gives the hour (stylised, stated honestly).
- `ganzhi` — the sexagenary cycle of stems and branches for year, month, day and double-hour. ⚠ close to `shichen`
- `wareki` — the Japanese era calendar (Reiwa) with hour and minute in formal kanji, as an official document. ⚠ close to `kanji-tategaki`, `japanese-readings`
- `runic-calendar` — a Scandinavian runic staff calendar with golden-number runes (pentadic numerals).
- `cyrillic-numerals` — Old Church Slavonic letter-numerals with titlo, on a manuscript page. ⚠ close to `greek-numerals`, `hebrew-numerals`
- `planetary-hours` — the Chaldean order of planetary hours (Saturn, Jupiter, Mars, Sun, Venus, Mercury, Moon) ruling each unequal hour, as a Renaissance almanac wheel. ⚠ unequal hours also in `wadokei`, `canonical-hours`, `roman-calendar` — make the planetary ruler the point
- `karuta` — the Hyakunin Isshu poem cards (classical poems, public domain): the reader's card for minute m, with a stated numbering. Words-adjacent; verify texts and readings
- `lunar-mansions` — the Chinese 28 xiu or Indian nakṣatra lunar mansions with the Moon's real position, as a star-chart dial. ⚠ nakṣatra also shown in `panchanga`
- `zmanim` — Jewish halakhic hours from today's sunrise and sunset. ⚠ unequal hours, as in `wadokei`, `canonical-hours` and `roman-calendar`
- `jagyeongnu` — Jang Yeong-sil's self-striking water clock (Korea, 1434): float rods release balls that trigger jacks striking bell, drum and gong.
- `ring-dial` — a brass astronomical ring dial: sunlight through a pinhole falls on the hour scale inside the ring.
- `railroad-watch` — a railroad-grade pocket watch to the 1890s American standards, with lever setting and a timetable card.
- `perpetual-calendar` — a perpetual-calendar watch movement with its 48-month cam and leap-year wheel.
- `alaturka` — Ottoman 'alaturka' hours counted from sunset, on a muvakkithane (timekeeper's house) dial. ⚠ `italian-hours`

## Words, scripts and numerals (`words`)
- `finnish-time` — Finnish (vaille, yli, puoli) with its "half to the next hour".
- `tagalog-time` — Filipino time-telling with Spanish-derived numbers (alas dos y medya) next to native Tagalog.
- `hawaiian-time` — ʻŌlelo Hawaiʻi time-telling, with ʻokina and kahakō rendered correctly.
- `armenian-numerals` — Armenian letter-numerals on an illuminated manuscript ground. ⚠ close to `greek-numerals`, `hebrew-numerals`
- `iroha` — the iroha poem's ordering used as numbers (as in old Japanese numbering), with the poem's text.
- `seal-script` — the time in Chinese seal script carved on a stone seal and stamped in vermilion. ⚠ close to `incense-seal`
- `tap-code` — prisoners' tap code grid, with knocks animating each digit.
- `telegraph-code` — the Chinese telegraph code: four-digit codes for the characters of the time phrase.
- `type-specimen` — a foundry type specimen where point sizes and line lengths spell the time.
- `letterpress` — a composing stick and chase setting the time in movable type, mirror-reversed, then printed.
- `dewey` — a library shelf where the call numbers of the books on display give the time.
- `ethiopic-numerals` — Geʽez numerals (separate signs for 1–10, tens, 100) for the time, drawn procedurally, without the 6 a.m. count. ⚠ `swahili-time`
- `korean-sino-native` — Korean's two number systems side by side (native hours, Sino-Korean minutes), with Hangul spelling rules. ⚠ `hangul`
- `rebus` — a Victorian picture-rebus puzzle whose pictures spell the time phrase.
- `semaphore-telegraph` — Chappe's optical telegraph arms on a tower spelling the digits in the 1794 code.
- `sign-language` — fingerspelled or number handshapes (state which sign language) for the digits, drawn as original hand illustrations.
- `bhutasankhya` — Sanskrit word-numerals (moon = 1, eyes = 2, fires = 3 …) composing the time as a verse-like chain, read right to left.
- `shorthand` — the time written in Pitman or Gregg shorthand on a reporter's notebook, with a key.
- `maori-time` — te reo Māori time-telling, with macrons correct.
- `basque-numbers` — Basque vigesimal numbers (berrogeita hamazazpi = 2×20 + 17) in time-telling.
- `swedish-time` — Swedish 'fem över halv tre' etc. ⚠ `german-words`, `dutch-words`

## Mechanical and display technology (`mechanical`)
- `rail-semaphore` — lower-quadrant semaphore signals whose arm positions encode the digits.
- `ferris-wheel` — a Ferris wheel whose lit gondolas and turning position read as a dial.
- `galileo-thermometer` — floating weighted bulbs with tags rising and sinking to show the digits. ⚠ close to `thermometers`
- `overbalanced-wheel` — a "perpetual motion" overbalanced wheel, honestly driven, with the history of the fallacy.
- `wankel` — a Wankel rotary engine whose rotor and eccentric shaft drive the hands.
- `differential` — an automobile differential splitting rotation into hour and minute outputs.
- `harmonic-drive` — a strain-wave gear with flexspline teeth, 100:1, driving a dial.
- `music-box` — a pinned cylinder music box whose pins are arranged as the digits (original melody). ⚠ close to `punched-card`, `piano-roll`
- `piano-roll` — a player-piano roll scrolling perforations that form the time. ⚠ close to `punched-card`, `music-box`
- `altimeter` — a three-pointer aircraft altimeter repurposed: pointers read hours, minutes and seconds. ⚠ close to `bourdon-gauges`, `car-dashboard`
- `combination-safe` — a safe's combination dial turning to the digits, with the wheel pack visible.
- `pin-tumbler` — a cutaway pin-tumbler lock whose pin stacks encode the digits.
- `radio-dial` — a valve radio's illuminated tuning dial, with stations at minute marks.
- `newtons-cradle` — Newton's cradle swinging out the seconds, with hour and minute ball counts.
- `spectrogram` — a sound whose spectrogram spells the time, scrolling on a sonograph roll.
- `bismuth-crystal` — iridescent stepped hopper crystals of bismuth grown into digit shapes.
- `cuckoo-organ` — a barrel organ whose pinned barrel plays an original tune for each minute (no copyrighted melodies).
- `astronomical-regulator` — a precision regulator with a mercury pendulum and a Riefler escapement in a vacuum case.
- `stirling-engine` — a model Stirling engine on a cup of hot water, flywheel driving a dial.
- `camera-shutter` — a leaf shutter and iris diaphragm whose blades open to stop numbers; exposures counted.
- `comptometer` — a key-driven adding machine with columns of keys, adding one each second.
- `gyroscope` — a precessing gyroscope on a pivot whose precession period reads as a hand.

## Everyday objects and signals (`everyday`)
- `fuel-pump` — a 1950s petrol pump's rolling price and volume wheels. ⚠ close to `odometer`
- `taxi-meter` — a mechanical taxi meter with flag, fare drum and extras. ⚠ close to `odometer`
- `cricket-scoreboard` — a manual cricket scoreboard with tin number plates being hung. ⚠ close to `scoreboard`
- `paper-tape` — five-hole teleprinter tape (ITA2) punched with the time and read back.
- `calculator` — a pocket calculator computing the time as a sum each second.
- `departure-gate` — an airport gate podium with an LCD 'boarding' panel and a jet bridge; boarding groups give the minutes.
- `bus-ticket-punch` — a conductor's ticket punch clipping a paper ticket at the stage numbers of hour and minute.
- `lift-buttons` — a lift car's button panel lighting floors HH and MM. ⚠ `elevator-dial`
- `sticky-notes` — a desk of sticky notes and highlighters on which the time is written and re-written.
- `kaiten-sushi` — a conveyor-belt sushi bar: colour-coded plates and stacked plates count the time.
- `toaster` — a pop-up toaster's browning dial and timer, toast popping each minute.
- `washing-machine` — a mechanical programme dial clicking round its cycle.
- `cafe-blackboard` — a café chalk menu whose prices read as the time.
- `bicycle-computer` — a handlebar cycle computer with wheel magnet and trip counters.

## Games, toys and puzzles (`games`)
- `shogi` — shogi pieces (kanji) positioned so that captured-piece counts give the time.
- `darts` — darts landing on numbered segments for hour, minute and second.
- `bowling` — ten-pin frames scoring the time.
- `sudoku` — a sudoku whose givens include the time's digits in a highlighted row.
- `peg-solitaire` — English peg solitaire jumping toward a time pattern.
- `roulette` — a roulette wheel with the ball settling on the second.
- `pachisi` — a cross-shaped pachisi board with cowrie throws.
- `spinning-tops` — a set of spinning tops, precessing, each numbered.
- `twisty-cube` — a generic twisty cube whose face stickers show digits after each twist sequence. ⚠ IP caution — avoid any branded cube trade dress
- `knights-tour` — a 6×10 board (60 squares, which has knight's tours): one square visited per second, a new tour each minute.
- `jacks` — a game of jacks: onesies to sixies, the round and count giving the time.
- `shogi` — shogi pieces with a clear exact reading still to be designed (piece-stand counts cannot exceed 18 pawns).
- `game-of-goose` — the 63-square Game of the Goose spiral with three tokens. ⚠ `snakes-ladders`
- `xiangqi` — Chinese chess pieces on the river board with an exact, stated reading.
- `curling` — stones in the house; distances or counts encode the time.
- `faro-shuffle` — a deck given perfect out-shuffles (52 cards return after 8); the shuffle count and card order give the time.
- `marbles` — a chalk ring of playground marbles knocked out by a shooter; counts by colour give the time.

## Cosmic and biological (`cosmic`)
- `retrograde` — Mars's retrograde loop against the stars from real ephemerides, with a date and time readout.
- `cepheid` — a Cepheid variable's light curve and period–luminosity scale as a clock.
- `sun-path` — a stereographic sun-path diagram for the viewer's location with today's track and the hour lines. ⚠ close to `sundial`, `sky-dome`, `analemma`
- `shadow-study` — an architect's shadow study of a small building through the day. ⚠ close to `sundial`, `shadow-clock`
- `cicada` — a periodical cicada's 17-year cycle as a dial, with the day's time.
- `sleeping-leaves` — a plant whose leaves fold at night (nyctinasty) following the sun, with a dial. ⚠ close to `floral-clock`, `sunflower`
- `cosmic-elements` — a periodic table coloured by the elements' cosmic origins, with Z = hour, minute and second lit. Two makers' runs ended in API content-filter errors after downloading a published periodic-table graphic; if retried, have the maker write the data from its own knowledge and download nothing.
- `geomagnetic-daily` — George Graham's 1722 discovery of the daily swing of the compass needle, as a magnetometer trace.
- `circadian-genes` — the PER/TIM transcription feedback loop in a fly neuron over 24 hours. ⚠ `kai-oscillator`
- `pole-precession` — the 25,800-year circle of the celestial pole among Polaris, Vega and Thuban, with a clock hand. ⚠ `star-trails`
- `retrograde` — Mars's retrograde loop against the stars from real ephemerides, with a planetarium console time readout.
- `aurora` — an auroral curtain over a snowy horizon, with the magnetometer trace and the time. ⚠ `terminator`
- `granulation` — the Sun's surface granules (8–20 min lifetimes) seen through a solar telescope, with spicules.
- `coral-night` — reef polyps that feed at night, opening by the real sunset, under a blue torch. ⚠ `bioluminescence`
- `three-body` — the Chenciner–Montgomery figure-eight three-body orbit, one lap per minute.

## Mathematical and algorithmic (`math`, `automata`)
- `knots` — knot diagrams whose crossing numbers give the digits.
- `tesseract` — a rotating tesseract with numbered cells.
- `hat-tiling` — the 2023 aperiodic "hat" monotile with tiles coloured to show the time.
- `newton-fractal` — Newton's method basins for zᵐ − 1 with m = minute-dependent. ⚠ close to `julia-set`
- `inversion` — circle inversion of a dial, the hands passing through the circle of inversion.
- `dozenal` — base-12 time with dozenal digit glyphs and a duodecimal dial. ⚠ close to `hexadecimal-time`, `balanced-ternary`
- `napiers-bones` — Napier's bones multiplying the hour by 60 and adding minutes.
- `number-rods` — coloured Cuisenaire-style rods composing the digits. ⚠ close to `counting-rods`
- `percolation` — percolation on a lattice with the occupation probability set by seconds.
- `langton-loops` — Langton's self-replicating loops colonising the digits.
- `huffman` — a Huffman tree built from the time phrase's letter frequencies.
- `l-system` — L-system plants whose branch counts give the time.
- `venation` — leaf venation by space colonisation growing toward digit-shaped auxin sources.
- `stippling` — Lloyd-relaxed stippling of the digits. ⚠ close to `pointillism`
- `ink-fluid` — a stable-fluids simulation where dye advects into the digits.
- `tesseract` — a rotating tesseract with numbered cells. ⚠ `dodecahedron`
- `continued-fraction` — the time of day as a fraction of the day, expanded as a continued fraction with its convergents drawn on a Stern–Brocot tree. ⚠ `farey`
- `rule-184` — the traffic automaton Rule 184 as a space-time diagram. ⚠ `traffic-jam`
- `knot-table` — knot diagrams from the Rolfsen table whose crossing numbers give the digits.
- `double-pendulum` — a chaotic double pendulum re-seeded each minute, its trace and energy shown.
- `riemann-zeros` — the zeta function along the critical line, with zeros as tick marks.
- `goldbach` — Goldbach partitions of the even numbers built from the time, as a comet plot.
- `josephus` — the Josephus elimination around a circle of 60, one per second.
- `catalan` — triangulations of a polygon / Dyck paths counted by Catalan numbers, drawing the time.

## Art and craft (`art`)
- `origami` — a paper crane folding sequence; the step number and creases give the time.
- `knitting` — fair-isle knitting with the time in the yoke pattern, needles adding stitches per second. ⚠ close to `cross-stitch`
- `sashiko` — sashiko stitching on indigo cloth, one stitch per second. ⚠ close to `cross-stitch`
- `pottery-wheel` — a pot thrown on a wheel; turns and rings mark the time.
- `marbling` — suminagashi/ebru paper marbling combing into the digits. ⚠ close to `cyclic-ca` (marbled spirals)
- `illuminated` — an illuminated initial and rubric giving the hour and minute. ⚠ close to `canonical-hours`
- `op-art` — an original op-art field whose distortion reveals the time. ⚠ close to `moire-reveal`
- `bauhaus` — a Bauhaus-style geometric composition reading as a clock. ⚠ close to `mondrian`, `swiss-poster`
- `constructivist` — a constructivist poster with diagonal bars and block numerals.
- `bonsai` — a bonsai whose pruning and wiring through the day trace the hour and minute branches.
- `glassblowing` — a gather of molten glass turned on a blowpipe, glowing and cooling through the minute.
- `bonsai` — a bonsai whose wiring and pruning trace the hour and minute branches.
- `stained-glass-gothic` — a Gothic rose window with lead cames and tracery. ⚠ `voronoi`
- `embroidery-goldwork` — couched gold thread on velvet forming the numerals. ⚠ `cross-stitch`
- `bobbin-lace` — a lace pillow with pins, bobbins and pricking; the lace's ground forms the numerals.
- `delft-tiles` — blue-and-white tin-glazed tiles with painted numerals and corner motifs. ⚠ `spanish-words` (azulejo)
- `pyrography` — numerals burnt into a limewood panel by a hot nib.
- `scrimshaw` — an engraved bone or ivory-substitute panel with inked lines, a ship and the time.
- `cloisonne` — cloisonné enamel with gold wire cells forming the numerals. ⚠ `art-nouveau`
- `thuluth` — Arabic thuluth calligraphy of the time phrase with reed-pen dots. ⚠ `arabic-words`
