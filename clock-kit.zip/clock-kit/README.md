# Clock kit

Everything needed to keep growing Tom Gally's clock gallery in a fresh conversation. The gallery itself is a single
self-contained HTML file; this kit holds the tools, briefs and records that make each expansion round repeatable.

## How to start a round

Open a new conversation, attach the latest gallery HTML and this kit as `clock-kit.zip`, and paste the prompt from
`STARTER_PROMPT.md`. Claude unpacks the kit, splits the gallery into editable parts, designs new concepts, has a
team of maker agents build and test them, reviews the results, reassembles the page, and returns a new HTML file and
an updated kit.

## Contents

| File | For | What it is |
|---|---|---|
| `STARTER_PROMPT.md` | Tom | The prompt to paste at the start of a round |
| `ORCHESTRATION.md` | Claude (orchestrator) | Step-by-step playbook for a round, with lessons learned and benchmarks |
| `BRIEF.md` | Claude (makers) | The API, quality bar, performance budget and testing procedure for writing clocks |
| `REGISTER.md` | both | Every clock so far: id, title, category, part file, one-line blurb; counts by category |
| `IDEAS.md` | Claude | A reservoir of about 150 unbuilt concept seeds (those close to an existing clock are flagged), grouped by category |
| `examples/ASSIGN-round2.md`, `examples/ASSIGN-round3.md` | Claude | Earlier rounds' assignment lists, as models of the format and level of detail (round 3's includes a look per entry) |
| `tools/split.py` | Claude | Splits the gallery HTML into `head.html`, `core.js`, `parts/part*.js`, `app.js`, `tail.html` |
| `tools/assemble.py` | Claude | Rebuilds the HTML from the parts, checks ids, renames the gallery after its count |
| `tools/test.mjs` | Claude | Headless-Chromium harness: runs a part's clocks through time jumps, rollovers, 3600× and pause at two sizes; reports errors and cost; writes snapshots |
| `tools/snap.mjs` | Claude | Renders chosen clocks at chosen times and dates |
| `tools/sheet.py` | Claude | Contact sheets of snapshots for visual review |
| `tools/pagetest.mjs` | Claude | Whole-page check: count, ids, random order, memory, blank cards, every spotlight, errors |
| `tools/register.mjs` | Claude | Regenerates `REGISTER.md` from the parts |
| `tools/timing.py` | Claude | Summarises draw cost from a sequential timing run, by group of parts |
| `tools/fps.mjs` | Claude | Steady-state gallery frame rate averaged over several random hangings (for comparing galleries) |
| `tools/pw.mjs` | Claude | Finds and launches the preinstalled Playwright/Chromium |

## How the gallery is built

`core.js` holds the clock registry (`defineClock`, `CATEGORIES`), the time object and the helper library `U`.
Each `parts/partN.js` defines a batch of clocks inside one function wrapper, starting with the marker line
`/* ===== partN.js ===== */`. `app.js` is the gallery: controls, rendering scheduler, random hanging order on each
load, tooltip, spotlight, and memory management (cards far from the viewport release their canvases and cached art,
so memory stays at roughly 40 MB of card canvases however many clocks there are). `split.py` followed by
`assemble.py` reproduces the HTML byte for byte.

## Changelog

- **Round 1** (earlier) — *A Hundred Clocks*: 100 clocks in six categories (parts 1–9).
- **Round 2** (16 Oct 2026) — *Two Hundred and Forty Clocks*: +140 clocks (parts 10–16), three new categories
  (Games, Toys & Puzzles; Everyday Objects & Signals; Art & Craft); grid order randomised on every load.
- **Kit v1** (16 Oct 2026) — memory fix in `app.js` (release of far-off canvases and caches; canvas memory after a
  full scroll fell from 223 MB to 42 MB and gallery frame rate rose from 11 to 28 fps in the headless test); this kit
  created: tools, brief, playbook, register of 240 clocks, idea reservoir.
- **Round 3** (16 Oct 2026) — *Three Hundred and Eighty Clocks*: +140 clocks (parts 17–24) in seven themed batches —
  art and craft (maki-e, kintsugi, kolam, cyanotype, millefiori…), games and toys (hanafuda, tangram, nim, zoetrope,
  pinball…), everyday objects (teletext, test card, advent calendar, vending machine…), mathematics and algorithms
  (Ford circles, Egyptian fractions, Ising, Lenia, Hamming code, wave-function collapse…), cosmic and biological
  (Galilean moons, KaiABC, zebrafish segmentation clock, gravitational-wave chirp, cuttlefish skin…), machines
  (Pascaline, rotor cipher, Williams tube, Strowger switch, Linotype, Antikythera…) and languages and calendars (Yoruba,
  Danish, Welsh, Turkish, Hungarian, Vietnamese, Ogham, chronogram, Aztec, panchāṅga, pawukon, change ringing…).
  Batch E was split over parts 21 and 24 after two maker runs ended in API errors. Kit changes: `U.roundRect` clamps a
  negative radius to 0 (it threw for tiny sizes); new `tools/fps.mjs`; playbook, brief and idea reservoir updated.
