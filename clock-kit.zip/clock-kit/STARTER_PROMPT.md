# Starter prompt

Start a new conversation, attach **two files** — the latest gallery HTML and `clock-kit.zip` — and paste the
prompt below. Change the number or add a focus line if you like; everything else can stay as it is.

---

Attached are my clock gallery (an HTML file) and its build kit (clock-kit.zip). Please run another expansion round,
following the kit's ORCHESTRATION.md.

- Add **140** new clocks (7 batches of 20), each as distinctive, beautiful and carefully made as the existing ones,
  with none repeating a concept, mechanism or look already in REGISTER.md. Draw on IDEAS.md and your own ideas.
- Work in orchestration mode: make the design decisions yourself without checking with me, and tell me at the end
  anything I should review.
- Test everything as the playbook describes, and send back weak clocks for revision before assembling.
- Return the updated gallery HTML (renamed for the new count) and an updated clock-kit.zip with the register, ideas,
  changelog and any improved tools.

*(Optional focus for this round: …)*

---

Notes
- Each round of 140 takes about three hours and runs on its own; you can leave it and come back.
- Keep the newest HTML and the newest kit together — the next round needs both.
- To ask for something other than a standard round (a category filter, revisions to particular clocks, a different
  number), say so in the prompt; the playbook still applies.
