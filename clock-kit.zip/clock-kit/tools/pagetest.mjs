// Whole-page check of the assembled gallery.
// usage: node tools/pagetest.mjs gallery.html [outdir]
// Loads three times (count, duplicate ids, title, order differs per load), scrolls the whole wall
// (canvas memory must stay bounded), changes grid density, checks visible cards are drawn, opens every
// spotlight, runs 3600× and a scrub, and reports any page/console errors. Writes page_top.png, page_spot.png.
import { launch } from './pw.mjs';
import path from 'path'; import fs from 'fs';
const file = 'file://' + path.resolve(process.argv[2]);
const out = process.argv[3] || 'pagetest'; fs.mkdirSync(out, { recursive: true });
const browser = await launch();
const ctx = await browser.newContext({ deviceScaleFactor: 2, timezoneId: 'Asia/Tokyo', viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
const errs = [];
page.on('pageerror', e => errs.push('pageerror: ' + String(e.stack || e).split('\n').slice(0, 3).join(' | ')));
page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errs.push('console.' + m.type() + ': ' + m.text()); });
const canvasMB = () => page.evaluate(() => { let s = 0, n = 0; for (const c of document.querySelectorAll('#wall canvas')) { const a = c.width * c.height; if (a > 1) { s += a; n++; } } return `${n} cards allocated, ${(s * 4 / 1048576).toFixed(0)} MB of card canvases`; });
const blankVisible = () => page.evaluate(() => { let bad = 0, n = 0; for (const card of document.querySelectorAll('#wall .card')) { const r = card.getBoundingClientRect(); if (r.bottom < 0 || r.top > innerHeight) continue; n++; const c = card.querySelector('canvas'); if (c.width < 2) { bad++; continue; } /* copy, so the card canvas itself is never read back */ const t = document.createElement('canvas'); t.width = t.height = 16; const g = t.getContext('2d', { willReadFrequently: true }); g.drawImage(c, 0, 0, 16, 16); const d = g.getImageData(0, 0, 16, 16).data; let lit = 0; for (let q = 3; q < d.length; q += 4) lit += d[q] > 0; if (!lit) bad++; } return `${bad} of ${n} visible cards blank`; });

const orders = [];
for (let k = 0; k < 3; k++) {
  await page.goto(file); await page.waitForTimeout(1500);
  const info = await page.evaluate(() => ({
    n: HundredClocks.CLOCKS.length, cards: document.querySelectorAll('#wall .card').length, title: document.title,
    ids: HundredClocks.order.map(c => c.id),
    cats: Object.entries(HundredClocks.CLOCKS.reduce((a, c) => (a[c.category] = (a[c.category] || 0) + 1, a), {})).map(([k, v]) => k + ' ' + v).join(', '),
    unknownCats: HundredClocks.CLOCKS.filter(c => !CATEGORIES[c.category]).map(c => c.id),
    dup: HundredClocks.CLOCKS.map(c => c.id).filter((x, i, a) => a.indexOf(x) !== i),
  }));
  orders.push(info.ids.join());
  if (k === 0) console.log(`title "${info.title}" · ${info.n} clocks · ${info.cards} cards · duplicate ids ${JSON.stringify(info.dup)} · unknown categories ${JSON.stringify(info.unknownCats)}\n  ${info.cats}`);
}
console.log('order differs between loads: ' + (orders[0] !== orders[1] && orders[1] !== orders[2]));
await page.screenshot({ path: path.join(out, 'page_top.png') });
console.log('after load: ' + await canvasMB());
const H = await page.evaluate(() => document.documentElement.scrollHeight);
for (let y = 0; y < H; y += 700) { await page.evaluate(y => scrollTo(0, y), y); await page.waitForTimeout(300); }
await page.waitForTimeout(1500);   // let freshly restored cards initialise and draw
console.log('after scrolling to the bottom: ' + await canvasMB() + ' · ' + await blankVisible());
await page.evaluate(() => { const d = document.querySelector('#density'); d.value = '120'; d.dispatchEvent(new Event('input', { bubbles: true })); });
await page.waitForTimeout(1200);
await page.evaluate(() => scrollTo(0, 0)); await page.waitForTimeout(1500);
console.log('dense grid, back at top: ' + await canvasMB() + ' · ' + await blankVisible());
await page.evaluate(() => { const d = document.querySelector('#density'); d.value = '210'; d.dispatchEvent(new Event('input', { bubbles: true })); });
await page.waitForTimeout(1500);
console.log('default grid: ' + await blankVisible());

const n = await page.evaluate(() => document.querySelectorAll('#wall .card').length);
const t0 = Date.now();
for (let i = 0; i < n; i++) {
  await page.evaluate(i => { const c = document.querySelectorAll('#wall .card')[i]; c.scrollIntoView({ block: 'center' }); c.click(); }, i);
  await page.waitForTimeout(200);
  if (i === 3) await page.screenshot({ path: path.join(out, 'page_spot.png') });
  await page.keyboard.press('Escape'); await page.waitForTimeout(30);
}
console.log(`opened ${n} spotlights in ${((Date.now() - t0) / 1000).toFixed(0)} s`);
await page.evaluate(() => scrollTo(0, 0));
const fps = await page.evaluate(() => new Promise(res => { let f = 0; const s = performance.now(); const tick = () => { f++; if (performance.now() - s < 3000) requestAnimationFrame(tick); else res(f / 3); }; requestAnimationFrame(tick); }));
console.log('gallery frame rate (headless, software rendering): ' + fps.toFixed(1) + ' fps');
await page.selectOption('#speed', '3600'); await page.waitForTimeout(3000); await page.selectOption('#speed', '1');
await page.evaluate(() => { const s = document.querySelector('#scrub'); s.value = '-700'; s.dispatchEvent(new Event('input', { bubbles: true })); });
await page.waitForTimeout(1500); await page.click('#now'); await page.waitForTimeout(800);
console.log(errs.length ? 'ERRORS (' + errs.length + '):\n  ' + [...new Set(errs)].slice(0, 40).join('\n  ') : 'no page errors');
await browser.close();
