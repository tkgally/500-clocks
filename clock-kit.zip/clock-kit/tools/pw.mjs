// Shared: load Playwright and launch the preinstalled Chromium (works in Claude's cloud workspace).
import fs from 'fs';
import path from 'path';
export async function launch() {
  let pw;
  try { pw = await import('playwright'); }
  catch { pw = await import('/opt/npm-tools/node_modules/playwright/index.mjs'); }
  let exe = process.env.CHROME_PATH;
  if (!exe) {
    const root = process.env.PLAYWRIGHT_BROWSERS_PATH || '/opt/pw-browsers';
    try {
      for (const d of fs.readdirSync(root).filter(d => d.startsWith('chromium-')).sort().reverse()) {
        const p = path.join(root, d, 'chrome-linux', 'chrome');
        if (fs.existsSync(p)) { exe = p; break; }
      }
    } catch {}
    if (!exe && fs.existsSync('/opt/pw-browsers/chromium')) exe = '/opt/pw-browsers/chromium';
  }
  return pw.chromium.launch(exe ? { executablePath: exe } : {});
}
