#!/usr/bin/env python3
"""Contact sheets of harness snapshots for quick visual review.

    python3 tools/sheet.py SNAPDIR KIND OUTPREFIX [--size 300] [--cols 5] [--per 20] [--ids a,b,...]

KIND is L1, L2 or S (the suffix of <id>_<KIND>.png written by tools/test.mjs). Without --ids,
every <id>_<KIND>.png in SNAPDIR is used, in name order. Writes OUTPREFIX_0.png, OUTPREFIX_1.png, ...
"""
import os, sys
from PIL import Image, ImageDraw
a = sys.argv[1:]
snap, kind, prefix = a[0], a[1], a[2]
opt = lambda k, d: a[a.index(k) + 1] if k in a else d
size, cols, per = int(opt('--size', 300)), int(opt('--cols', 5)), int(opt('--per', 20))
ids = opt('--ids', '')
ids = ids.split(',') if ids else sorted(f[:-len(kind) - 5] for f in os.listdir(snap) if f.endswith(f'_{kind}.png'))
for p in range(0, len(ids), per):
    chunk = ids[p:p + per]; rows = (len(chunk) + cols - 1) // cols
    im = Image.new('RGB', (cols * (size + 8), rows * (size + 22)), (30, 30, 30)); d = ImageDraw.Draw(im)
    for k, i in enumerate(chunk):
        x, y = (k % cols) * (size + 8), (k // cols) * (size + 22)
        f = os.path.join(snap, f'{i}_{kind}.png')
        if os.path.exists(f): im.paste(Image.open(f).convert('RGB').resize((size, size), Image.LANCZOS), (x, y))
        d.text((x + 2, y + size + 4), i, fill=(230, 230, 230))
    im.save(f'{prefix}_{p // per}.png'); print(f'{prefix}_{p // per}.png')
