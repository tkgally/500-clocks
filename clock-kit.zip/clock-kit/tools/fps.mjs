// Steady-state gallery frame rate, averaged over several random hangings.
// usage: node tools/fps.mjs gallery.html [loads=5] [seconds=4]
// Each load: open the page at 1440×900, DPR 2, wait 3 s for the visible cards to initialise, then count
// requestAnimationFrame callbacks for the given seconds. Reports each load and the mean. Headless software
// rendering, so compare galleries on the same machine rather than against absolute numbers.
import { launch } from './pw.mjs';
import path from 'path';
const file = 'file://' + path.resolve(process.argv[2]);
const loads = +(process.argv[3] || 5), secs = +(process.argv[4] || 4);
const browser = await launch();
const ctx = await browser.newContext({ deviceScaleFactor: 2, timezoneId: 'Asia/Tokyo', viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
const r = [];
for (let k = 0; k < loads; k++) {
  await page.goto(file); await page.waitForTimeout(3000);
  r.push(await page.evaluate((secs) => new Promise(res => { let f = 0; const s = performance.now(); const tick = () => { f++; if (performance.now() - s < secs * 1000) requestAnimationFrame(tick); else res(f / secs); }; requestAnimationFrame(tick); }), secs));
}
console.log(`${path.basename(file)}: ${r.map(x => x.toFixed(1)).join(', ')} fps · mean ${(r.reduce((a, b) => a + b, 0) / r.length).toFixed(1)} fps`);
await browser.close();
