// Render chosen clocks at chosen times: runs 3 s of frames up to the time given, then draws ONE frame 0.5 s after it
// (so asking for x:00:01 shows x:00:01.5). Optional --tz Europe/London (default Asia/Tokyo).
// usage (from the build directory): node tools/snap.mjs parts/partNN.js outdir size id@HH:MM:SS[@YYYY-MM-DD] ...  (default date 2026-10-16)
// Tip: check word/number clocks at awkward times (00:00, 12:00, x:15, x:45, x:59) and ~1 s after a minute change.
import { launch } from './pw.mjs';
import fs from 'fs'; import path from 'path';
const argv = process.argv.slice(2);
const tzAt = argv.indexOf('--tz'); const tz = tzAt >= 0 ? argv.splice(tzAt, 2)[1] : 'Asia/Tokyo';
const [part, out, size, ...specs] = argv;
fs.mkdirSync(out, { recursive: true });
const core = fs.readFileSync(path.resolve('core.js'), 'utf8');
const src = fs.readFileSync(part, 'utf8');
const html = `<!doctype html><meta charset=utf-8><body><script>${core}</script><script>${src}</script>`;
fs.writeFileSync(path.join(out, '_s.html'), html);
const b = await launch();
const p = await (await b.newContext({ deviceScaleFactor: 2, timezoneId: tz })).newPage();
p.on('pageerror', e => console.log('ERR', e.message));
await p.goto('file://' + path.resolve(out, '_s.html'));
for (const sp of specs) {
  const [id, hms, ymd = '2026-10-16'] = sp.split('@'); const [h, m, s] = hms.split(':').map(Number);
  const [Y, M, D] = ymd.split('-').map(Number);
  const url = await p.evaluate(([id, h, m, s, size, Y, M, D]) => {
    const c = CLOCKS.find(c => c.id === id); const cv = document.createElement('canvas');
    cv.width = cv.height = size * 2; const g = cv.getContext('2d');
    if (!c) throw new Error('no clock ' + id);
    const base = new Date(Y, M - 1, D, h, m, s, 0).getTime() - 3000; let st = null;
    for (let f = 0; f <= 90; f++) { const ms = base + f * 1000 / 30 + 0; const T = makeTime(ms, f / 30, 1, false); T.dt = f ? 1 / 30 : 0; T.vdt = f ? 1 / 30 : 0; T.jump = f === 0;
      if (!st) st = c.init ? c.init(size, size, T) || {} : {}; g.setTransform(2, 0, 0, 2, 0, 0); g.save(); c.draw(g, size, size, T, st); g.restore(); }
    // final exact frame a bit after the target second
    const T = makeTime(base + 3000 + 500, 4, 1, false); T.dt = 1 / 30; T.vdt = 1 / 30; T.jump = false;
    g.setTransform(2, 0, 0, 2, 0, 0); g.save(); c.draw(g, size, size, T, st); g.restore();
    return cv.toDataURL();
  }, [id, h, m, s, +size, Y, M, D]);
  const f = path.join(out, `${id}_${ymd === '2026-10-16' ? '' : ymd + '_'}${hms.replace(/:/g, '')}.png`);
  fs.writeFileSync(f, Buffer.from(url.split(',')[1], 'base64')); console.log(f);
}
await b.close();
