#!/usr/bin/env python3
"""Summarise draw cost from test.mjs output (run test.mjs SEQUENTIALLY for meaningful numbers).

    for f in parts/part*.js; do echo "== $f"; node tools/test.mjs $f --nopng --out $S/t; done > $S/timing.txt
    python3 tools/timing.py $S/timing.txt [--groups 1-9,10-16,17-23]

Prints mean average draw time at 140 px and 460 px per group of part numbers, plus the slowest clocks.
"""
import re, sys
txt = open(sys.argv[1]).read()
groups = sys.argv[sys.argv.index('--groups') + 1] if '--groups' in sys.argv else ''
rows, part = [], None
for line in txt.splitlines():
    m = re.match(r'== .*part(\d+)\.js', line)
    if m: part = int(m.group(1)); continue
    m = re.match(r'\[(.{4})\] (\S+)\s+140px avg ([\d.]+)ms max [\d.]+ \| 460px avg ([\d.]+)ms', line)
    if m: rows.append((part, m.group(2), m.group(1).strip(), float(m.group(3)), float(m.group(4))))
def show(label, rs):
    if rs: print(f'{label:>14}: {len(rs):4d} clocks · mean {sum(r[3] for r in rs)/len(rs):.2f} ms at 140 px · {sum(r[4] for r in rs)/len(rs):.2f} ms at 460 px')
show('all', rows)
for g in filter(None, groups.split(',')):
    a, b = (int(x) for x in g.split('-'))
    show(f'parts {a}-{b}', [r for r in rows if r[0] is not None and a <= r[0] <= b])
print('flagged:', ', '.join(f'{r[1]} ({r[2]})' for r in rows if r[2] != 'ok') or 'none')
print('slowest at 460 px:', ', '.join(f'{r[1]} {r[4]}' for r in sorted(rows, key=lambda r: -r[4])[:8]))
