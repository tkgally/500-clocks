#!/usr/bin/env python3
"""Rebuild the single-file gallery from the pieces in the current directory.

    python3 tools/assemble.py out.html [--keep-title]
    python3 tools/assemble.py --auto            # file named after the count: three-hundred-eighty-clocks.html

Concatenates head.html, core.js, parts/part*.js (numeric order), app.js, tail.html.
Counts the clocks, renames the gallery after the count ("Three Hundred and Eighty Clocks")
unless --keep-title, and refuses to build if an id is duplicated or a part contains '</script'.
"""
import os, re, sys

out = sys.argv[1]   # or --auto: name the file after the count, e.g. three-hundred-eighty-clocks.html
keep = '--keep-title' in sys.argv
rd = lambda p: open(p, encoding='utf-8').read()
parts = sorted([p for p in os.listdir('parts') if re.match(r'part\d+\.js$', p)], key=lambda n: int(re.sub(r'\D', '', n)))
bodies = [rd(os.path.join('parts', p)) for p in parts]

ids = []
for p, b in zip(parts, bodies):
    if not b.startswith(f'/* ===== {p} ===== */'):
        raise SystemExit(f'{p} must begin with the marker line  /* ===== {p} ===== */')
    calls = len(re.findall(r'defineClock\(\{', b))
    found = re.findall(r"defineClock\(\{\s*id:\s*['\"]([^'\"]+)['\"]", b)
    if calls != len(found):
        raise SystemExit(f'{p}: {calls} defineClock({{ calls but {len(found)} with id as the first property — put id first')
    if '</script' in b.lower():
        raise SystemExit(f'{p} contains "</script" — split the string, e.g. "<\\/script"')
    ids += found
dups = sorted({i for i in ids if ids.count(i) > 1})
if dups:
    raise SystemExit('duplicate ids: ' + ', '.join(dups))
n = len(ids)

ONES = 'zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen'.split()
TENS = '_ _ twenty thirty forty fifty sixty seventy eighty ninety'.split()
def words(n):
    if n < 20: return ONES[n]
    if n < 100: return TENS[n // 10] + ('-' + ONES[n % 10] if n % 10 else '')
    if n < 1000:
        h = ONES[n // 100] + ' hundred'
        return h + (' and ' + words(n % 100) if n % 100 else '')
    if n == 1000: return 'one thousand'
    th = words(n // 1000) + ' thousand'
    r = n % 1000
    return th + ((' and ' if r < 100 else ' ') + words(r) if r else '')
name = words(n)
if n == 100: name = 'a hundred'
if n == 1000: name = 'a thousand'
Title = ' '.join(w if w == 'and' else w[0].upper() + w[1:] for w in name.split(' '))   # "Two Hundred and Forty"
Title = re.sub(r'-(\w)', lambda m: '-' + m.group(1).upper(), Title)

if out == '--auto':
    out = name.replace(' and ', ' ').replace(' ', '-') + '-clocks.html'
head, core, app = rd('head.html'), rd('core.js'), rd('app.js')
if not keep:
    head = re.sub(r'<title>.*?</title>', f'<title>{Title} Clocks</title>', head, count=1)
    head = re.sub(r'(</svg>)[^<]*?Clocks(</span>)', lambda m: m.group(1) + Title.replace(' ', '&nbsp;') + '&nbsp;Clocks' + m.group(2), head, count=1)
    head = re.sub(r'aria-label="Gallery of [^"]*clocks"', f'aria-label="Gallery of {name} clocks"', head, count=1)
    core = re.sub(r'^(\s*)[^\n]*? Clocks — core', lambda m: m.group(1) + f'{Title} Clocks — core', core, count=1, flags=re.M)
    app = re.sub(r'^(\s*)[^\n]*? Clocks — application', lambda m: m.group(1) + f'{Title} Clocks — application', app, count=1, flags=re.M)

nl = lambda t: t if t.endswith('\n') else t + '\n'
page = nl(head) + nl(core) + ''.join(nl(b) for b in bodies) + nl(app) + rd('tail.html')
open(out, 'w', encoding='utf-8').write(page)
print(f'{out}: {n} clocks from {len(parts)} parts, {len(page.encode()) / 1e6:.2f} MB, title "{Title} Clocks"' + (' (kept)' if keep else ''))
