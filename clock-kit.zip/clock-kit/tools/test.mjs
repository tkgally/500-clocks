// Clock test harness.
// usage (from the build directory): node tools/test.mjs parts/partNN.js [--ids a,b,c] [--out dir] [--tz Asia/Tokyo] [--nopng] [--core core.js]
// Loads core.js + the part file in headless Chromium, runs every clock defined by the part
// through a sequence of times (normal running, jumps, midnight/noon rollovers, pause),
// at a small card size and a large spotlight size, reports exceptions and draw cost,
// and writes PNG snapshots (<out>/<id>_L1.png, _L2.png at 460px; _S.png at 140px).
import { launch } from './pw.mjs';
import fs from 'fs';
import path from 'path';

const args = process.argv.slice(2);
const part = args[0];
const opt = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const ids = opt('--ids', '');
const out = opt('--out', 'shots');
const tz = opt('--tz', 'Asia/Tokyo');
const nopng = args.includes('--nopng');
const core = fs.readFileSync(path.resolve(opt('--core', 'core.js')), 'utf8');
const src = fs.readFileSync(part, 'utf8');
fs.mkdirSync(out, { recursive: true });

const runner = `
window.__run = async function (ids) {
  const before = window.__before;
  let list = CLOCKS.slice(before);
  if (ids) { const want = ids.split(','); list = CLOCKS.filter(c => want.includes(c.id)); }
  const res = [];
  const mk = (y, mo, d, h, mi, s, ms = 0) => new Date(y, mo, d, h, mi, s, ms).getTime();
  // [label, startMs, frames, dt(s), speed, paused]
  const seq = [
    ['A', mk(2026, 9, 16, 14, 37, 21, 100), 100, 1 / 30, 1, false],
    ['B', mk(2026, 9, 16, 9, 5, 58, 0), 70, 1 / 30, 1, false],        // jump; crosses 09:06:00
    ['C', mk(2026, 9, 16, 23, 59, 58, 500), 70, 1 / 30, 1, false],     // crosses midnight
    ['D', mk(2026, 9, 17, 11, 59, 59, 0), 40, 1 / 30, 3600, false],    // fast forward through noon
    ['E', mk(2026, 2, 3, 0, 0, 0, 0), 10, 1 / 30, 1, true],            // paused at exact midnight, other season
    ['F', mk(2026, 9, 16, 12, 0, 0, 0), 6, 1 / 30, 1, false],
    ['G', mk(2026, 9, 16, 19, 59, 59, 900), 8, 1 / 30, 1, false],
  ];
  for (const clock of list) {
    const r = { id: clock.id, title: clock.title, errors: [], cost: {}, snaps: {} };
    for (const fld of ['id', 'title', 'category', 'blurb', 'read', 'about']) if (!clock[fld]) r.errors.push('missing field ' + fld);
    if (clock.category && !CATEGORIES[clock.category]) r.errors.push('unknown category ' + clock.category);
    for (const size of [140, 460]) {
      const cv = document.createElement('canvas'); document.body.appendChild(cv);
      const dpr = window.devicePixelRatio || 1;
      cv.width = Math.round(size * dpr); cv.height = Math.round(size * dpr);
      const g = cv.getContext('2d');
      let state = null, lastMs = 0, real = 0, n = 0, tot = 0, max = 0, first = true;
      const draw = (ms, dt, speed, paused, jump, snapName) => {
        const T = makeTime(ms, real, speed, paused);
        T.dt = paused ? 0 : dt; T.vdt = lastMs ? (ms - lastMs) / 1000 : 0; T.jump = jump;
        const t0 = performance.now();
        try {
          if (first) { state = clock.init ? clock.init(size, size, T) || {} : {}; first = false; }
          g.setTransform(dpr, 0, 0, dpr, 0, 0); g.save(); clock.draw(g, size, size, T, state); g.restore(); g.getImageData(0, 0, 1, 1);
        } catch (e) { r.errors.push(size + 'px @' + new Date(ms).toString().slice(16, 24) + ': ' + (e && e.stack ? e.stack.split('\\n').slice(0, 3).join(' | ') : e)); }
        const c = performance.now() - t0; if (!jump) { tot += c; n++; max = Math.max(max, c); }
        lastMs = ms; if (!paused) real += dt;
        if (snapName) r.snaps[snapName] = cv.toDataURL('image/png');
      };
      for (const [label, start, frames, dt, speed, paused] of seq) {
        for (let f = 0; f < frames; f++) {
          const ms = paused ? start : start + f * dt * 1000 * speed;
          let snap = null;
          if (f === frames - 1) {
            if (size === 460 && label === 'A') snap = 'L1';
            if (size === 460 && label === 'B') snap = 'L2';
            if (size === 140 && label === 'A') snap = 'S';
          }
          draw(ms, dt, speed, paused, f === 0, snap);
          if (r.errors.length > 6) break;
        }
      }
      cv.remove(); r.cost[size] = { avg: +(tot / Math.max(1, n)).toFixed(2), max: +max.toFixed(1) };
    }
    res.push(r);
  }
  return res;
};
`;

const html = `<!doctype html><html><head><meta charset="utf-8"></head><body style="margin:0;background:#222">
<script>${core}
window.__before = CLOCKS.length;
</script>
<script>${src}</script>
<script>${runner}</script></body></html>`;
const tmp = path.join(out, '__harness.html');
fs.writeFileSync(tmp, html);

const browser = await launch();
const ctx = await browser.newContext({ deviceScaleFactor: 2, timezoneId: tz, viewport: { width: 800, height: 600 } });
const page = await ctx.newPage();
const pageErrors = [];
page.on('pageerror', e => pageErrors.push(String(e)));
page.on('console', m => { if (m.type() === 'error') pageErrors.push('console: ' + m.text()); });
await page.goto('file://' + path.resolve(tmp));
if (pageErrors.length) console.log('PAGE ERRORS:\n  ' + pageErrors.join('\n  '));
const defined = await page.evaluate(() => CLOCKS.slice(window.__before).map(c => c.id));
console.log(`part defines ${defined.length} clocks: ${defined.join(', ')}`);
const dup = defined.filter((x, i) => defined.indexOf(x) !== i);
if (dup.length) console.log('DUPLICATE IDS: ' + dup.join(', '));
const res = await page.evaluate(i => window.__run(i), ids);
if (!res.length) { console.log(ids ? `no clocks matched --ids ${ids} (check which part defines them: grep -l "id: '<id>'" parts/*.js)` : 'this part defines no clocks'); await browser.close(); process.exit(2); }
let bad = 0;
for (const r of res) {
  const flag = r.errors.length ? 'FAIL' : (r.cost[460].avg > 12 || r.cost[140].avg > 3 ? 'SLOW' : ' ok ');
  if (r.errors.length) bad++;
  console.log(`[${flag}] ${r.id.padEnd(26)} 140px avg ${r.cost[140].avg}ms max ${r.cost[140].max} | 460px avg ${r.cost[460].avg}ms max ${r.cost[460].max}`);
  for (const e of r.errors) console.log('       ' + e);
  if (!nopng) for (const [k, url] of Object.entries(r.snaps)) fs.writeFileSync(path.join(out, `${r.id}_${k}.png`), Buffer.from(url.split(',')[1], 'base64'));
}
console.log(`${res.length} clocks tested, ${bad} with errors. (Timings are inflated several-fold when other browsers run at the same time; judge SLOW from a solo run.) Snapshots in ${out}/ (L1 = 14:37:24 at 460px, L2 = 09:06:00 at 460px, S = 14:37:24 at 140px; all Asia/Tokyo unless --tz)`);
await browser.close();
if (bad) process.exitCode = 1;
