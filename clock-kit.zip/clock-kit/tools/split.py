#!/usr/bin/env python3
"""Split the single-file gallery into editable pieces in the current directory.

    python3 tools/split.py gallery.html

Writes head.html (up to and including the opening <script> line), core.js (registry and helper
library U), parts/partN.js (one file per `/* ===== partN.js ===== */` marker), app.js (gallery
application) and tail.html (closing </script> onward). tools/assemble.py rebuilds the page.
"""
import os, re, sys

src = open(sys.argv[1], encoding='utf-8').read()
lines = src.split('\n')

def find(pred, start=0):
    for i in range(start, len(lines)):
        if pred(lines[i]):
            return i
    raise SystemExit('marker not found')

i_script = find(lambda l: l.strip() == '<script>')
i_first_part = find(lambda l: re.match(r'^/\* ===== part\d+\.js ===== \*/', l), i_script)
i_app_title = find(lambda l: '— application:' in l, i_first_part)
i_app = i_app_title - 1                      # the '/* ====' line that opens the app banner
assert lines[i_app].startswith('/* ='), 'unexpected app banner'
i_end = max(i for i, l in enumerate(lines) if l.strip() == '</script>')

def write(name, chunk, last=False):
    # verbatim, so that split followed by assemble reproduces the page byte for byte
    open(name, 'w', encoding='utf-8').write('\n'.join(chunk) + ('' if last else '\n'))

write('head.html', lines[:i_script + 1])
write('core.js', lines[i_script + 1:i_first_part])
write('app.js', lines[i_app:i_end])
write('tail.html', lines[i_end:], last=True)
os.makedirs('parts', exist_ok=True)
starts = [i for i in range(i_first_part, i_app) if re.match(r'^/\* ===== part\d+\.js ===== \*/', lines[i])]
for k, s in enumerate(starts):
    e = starts[k + 1] if k + 1 < len(starts) else i_app
    name = re.match(r'^/\* ===== (part\d+\.js) ===== \*/', lines[s]).group(1)
    write(os.path.join('parts', name), lines[s:e])
names = sorted(os.listdir('parts'), key=lambda n: int(re.sub(r'[^0-9]', '', n) or 0))
print(f'head.html, core.js, app.js, tail.html and {len(starts)} parts written ({", ".join(names)})')
