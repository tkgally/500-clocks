# Orchestration playbook (for Claude running a round)

A *round* adds a batch of new clocks to the gallery — by default **140 = 7 makers × 20** — and returns the
updated gallery HTML plus an updated copy of this kit. Work in orchestration mode: make the design decisions
yourself, don't stop to ask unless genuinely blocked, and report anything Tom should review at the end.

The gallery HTML is the source of truth. The kit (tools, briefs, register, ideas) travels with it between
conversations, because the cloud workspace is temporary.

## Paths used below

- **BUILD** — the build directory, e.g. `/home/claude/build` (any writable place outside the uploads folder).
- **S** — a folder for this round's scratch output, e.g. `<session scratchpad>/round`. Each maker's scratch folder
  is `S/makers/NN` (NN = its part number).
- Shell variables and `cd` do **not** persist between Bash calls, so write these as literal absolute paths in every
  command and every maker prompt, and start each tool command with `cd BUILD && …` (the tools find `core.js` and
  `parts/` in the current directory).
- Attachments from Tom are in `/mnt/user-data/uploads/` in some environments and `/root/.claude/uploads/<id>/` (with a
  random prefix on each file name) in others — use the paths given with the message; the gallery's name varies with its count.
- Deliverables can go in `/mnt/user-data/outputs/` where it exists, otherwise in S; send them with SendUserFile.

## 0. Task list

Create a task list: set up · choose concepts · build (N batches) · review · assemble and test · update kit · deliver.

## 1. Set up (≈10 min)

```
mkdir -p BUILD S && cd BUILD && unzip -oq /mnt/user-data/uploads/clock-kit.zip && cp -r clock-kit/* . && rm -rf clock-kit
cp /mnt/user-data/uploads/<gallery>.html BUILD/gallery.html
cd BUILD && python3 tools/split.py gallery.html          # → head.html core.js parts/part*.js app.js tail.html
cd BUILD && python3 tools/assemble.py S/roundtrip.html --keep-title && cmp gallery.html S/roundtrip.html && echo IDENTICAL
cd BUILD && node tools/test.mjs parts/part4.js --ids nixie --out S/check     # expect: 1 clock, [ ok ] nixie
```
If the round-trip isn't identical, find out why before changing anything. `tools/sheet.py` needs Pillow
(`pip install --break-system-packages pillow` if missing). Playwright and Chromium are preinstalled in the
workspace; `tools/pw.mjs` finds them (override with `CHROME_PATH`).

## 2. Choose concepts

Read `REGISTER.md` (every existing clock) and `IDEAS.md` (a reservoir of unbuilt seeds, some flagged with the
existing clock they risk echoing). Choose N concepts:

- **Genuinely distinct**: a new mechanism, culture, phenomenon or craft, *and* a new visual world. Another
  language or numeral system qualifies only if its content and its look are both clearly different from what exists.
  Reject anything that would read as a reskin of an existing clock.
- **Balanced**: favour categories with few clocks (see the register's counts); mix playful and scholarly; mix
  analogue, digital, simulated and textual readings. Each batch of 20 should share a domain (one maker benefits
  from it) but be internally varied.
- **Readable**: each concept needs a clear, exact way to read hours, minutes and (usually) seconds. Write the reading
  scheme into the assignment; invented conventions are fine if stated.
- **Varied in look across batches**: give each entry a material/palette so that makers in different batches don't
  converge on the same brass, lacquer or CRT green.
- **Grounded**: prefer ideas with real history, science or craft behind them, so `about` has substance.
- **Safe**: no trademarked designs, characters or brand trade dress; no copied artworks; generic titles.
- A new category is allowed when a cluster warrants it: add `key: 'Label'` to `CATEGORIES` in `core.js` *before*
  makers start (also update the category list in core.js's header comment), and tell the makers.
- Ids: kebab-case, short, never reused (`grep -c '`my-id`' REGISTER.md` must print 0).

Write `BUILD/ASSIGN.md` (see `examples/ASSIGN-round2.md` for the level of detail; that round predates the look field) with one section per batch, labelled A, B, C… and numbered from the next free part
(round 4 starts at part25): `## Batch A → parts/part25.js`. Each entry:
`` `id` — Title (category): concept; look/material; reading requirement``.
Remove the ideas you used from `IDEAS.md` and add good new ones that occur to you.

## 3. Build

Launch one general-purpose subagent per batch, **all in one message, in the background**. Prompt template
(fill in the literal paths):

> You are building 20 new animated canvas clocks for an existing HTML gallery. The build directory is BUILD.
> First read BUILD/BRIEF.md completely, then your assignment, which is Batch X in BUILD/ASSIGN.md. Write your code
> to BUILD/parts/partNN.js (first line exactly `/* ===== partNN.js ===== */`). Your scratch folder is S/makers/NN;
> keep all snapshots and helper scripts there. Study the exemplar clocks named in the brief before writing.
> Work in stages (a few clocks at a time), testing with
> `cd BUILD && node tools/test.mjs parts/partNN.js --out S/makers/NN/shots`, and look at every snapshot with the Read
> tool to confirm each clock looks polished and shows the correct time. Don't touch any other file in BUILD.
> Finish with all clocks error-free, none SLOW (judged on a solo run), and each visually checked. Reply briefly with
> the per-clock harness lines and any caveats.

Add batch-specific emphasis where useful (linguistic accuracy for language batches, published algorithms for
science batches, mechanism correctness for machines). A round of 140 took about 3 hours wall-clock and about
3 million subagent tokens (each maker ≈ 375–470k). Round 3: makers took 56–90 min and 520–620k tokens each; with
revisions and a re-launched batch the round used about 4.9 million subagent tokens and about 4 hours.
If the Agent tool has no background option, launching all makers in one message still runs them in parallel;
the call returns when the last one finishes.

If a maker dies (API error), its part file keeps whatever it finished. Check it with `node --check` and
`grep -o "id: '[a-z0-9-]*'"`, then launch a fresh maker to add the missing ids to the same file (tell it which
clocks to leave untouched), or split the remainder into a new part number. Round 3 lost two runs to content-filter
errors after makers downloaded a published periodic-table graphic for `cosmic-elements`; replacing that concept
ended the failures.

## 4. Review (don't skip)

When all makers are done, for each new part NN:
```
cd BUILD && node tools/test.mjs parts/partNN.js --out S/final/sNN > S/final/logNN.txt 2>&1    # several may run in parallel
cd BUILD && python3 tools/sheet.py S/final/sNN L1 S/final/L1_NN
cd BUILD && python3 tools/sheet.py S/final/sNN L2 S/final/L2_NN --size 200 --cols 10
cd BUILD && python3 tools/sheet.py S/final/sNN S  S/final/S_NN --size 140 --cols 10 --per 70
```
- Look at every L1 and S sheet (and L2 for transition states). Check that each clock is polished, readable at
  140 px, and shows **14:37:24** (L1/S) or **09:06:00** (L2). Open full-size snapshots of anything doubtful.
- Word and numeral clocks: render awkward times with `tools/snap.mjs` (00:00, 12:00, x:15, x:45, x:59, and just
  after a minute change) and read the text yourself. snap.mjs draws 0.5 s after the time given, so ask for x:00:01
  to see x:00:01.5. Round 2 found phrases that crossfade over < 1 s at the minute — acceptable — so judge at ≥ 1 s.
- Recompute any numeric claim independently (Unix time, Julian Date, Mars Sol Date, check digits…).
- Send weak clocks back to their maker with SendMessage and specific feedback (round 2: the ferrofluid digits were
  illegible; the maker reworked them into joined glossy strokes). If a maker can't be reached, launch a fresh agent
  with BRIEF.md, the part file, the clock id and the feedback. Re-test after revisions.
- Parallel runs inflate timings 3–5×; judge performance in step 5.

## 5. Assemble and test the page

```
cd BUILD && python3 tools/assemble.py --auto        # names the file after the count, e.g. three-hundred-eighty-clocks.html
cd BUILD && node tools/pagetest.mjs <that file> S/page
cd BUILD && for f in parts/part*.js; do echo "== $f"; node tools/test.mjs $f --nopng --out S/t; done > S/timing.txt   # sequential, ~10–15 min
cd BUILD && python3 tools/timing.py S/timing.txt --groups 1-9,10-16,17-23
```
`pagetest` must show: the right count, no duplicate ids or unknown categories, a different order on each load,
bounded canvas memory after scrolling the whole wall (≈ 40 MB at a 1440×900 window with device pixel ratio 2,
independent of the clock count), 0 blank visible cards, every spotlight opened, and **no page errors**.
Benchmarks from round 3 (sequential, same machine for all groups): parts 1–9 (the original hundred) 0.60 ms at
140 px / 3.01 ms at 460 px; parts 10–16 0.44 / 2.18 ms; parts 17–24 0.62 / 3.03 ms; all 380 0.55 / 2.71 ms. (Round 2
measured 0.71 / 4.57 and 0.56 / 3.29 on a slower machine — compare groups within one run.) New clocks should not
raise these much. pagetest's frame-rate figure is a single 3-second sample taken just after a scroll, so it varies
by ±30 % between runs; for a fair comparison run `node tools/fps.mjs <old>.html 6` and `node tools/fps.mjs <new>.html 6`
(round 3: 18.4 fps for 240 clocks vs 17.0 fps for 380). pagetest also counts Chrome *warnings* as errors (e.g. the
`willReadFrequently` readback warning). In round 3's sequential run five of the original hundred were flagged SLOW (times-table 32 ms at 460 px,
prague-orloj, interference, pythagoras-tree, lissajous); optimising them is optional work for a quieter round.

## 6. Update the kit and deliver

```
cd BUILD && node tools/register.mjs REGISTER.md
```
Update: `README.md` (changelog line: round, date, count, notable additions, tool changes); `IDEAS.md`;
`BRIEF.md` if makers should know something new; and the count-specific figures in this file (file size, benchmarks,
"round N starts at partNN"). Then package the kit — docs, `REGISTER.md`, `IDEAS.md` and `tools/`, *not* the split
parts (the HTML carries them):
```
rm -rf S/pkg && mkdir -p S/pkg/clock-kit && cd BUILD && cp -r README.md STARTER_PROMPT.md BRIEF.md ORCHESTRATION.md REGISTER.md IDEAS.md tools examples S/pkg/clock-kit/ && cp ASSIGN.md S/pkg/clock-kit/examples/ASSIGN-roundN.md
cd S/pkg && zip -qr clock-kit.zip clock-kit && cp clock-kit.zip BUILD/<new gallery>.html /mnt/user-data/outputs/
```
Send Tom the new HTML and `clock-kit.zip` with SendUserFile. Final message: the count, a few highlights by group,
anything to review (language choices, invented conventions, simplifications), and the cost of the round.

## Lessons from earlier rounds

- The bottleneck is ideas, not effort: per-clock quality holds when each maker builds ~20. Keep `IDEAS.md` stocked.
- The most common weakness is legibility on the 140 px card; the second is a transition that briefly shows a wrong value.
- Makers sometimes overwrite files in a shared scratch folder — give each its own.
- `init` is re-run whenever a card returns from far off-screen (the gallery releases far-away canvases and caches to
  bound memory), so it must be repeatable and reasonably fast.
- The page is about 12.6 KB per clock (2.75 MB at 240; 4.79 MB at 380 — round 3's clocks average ≈ 14.6 KB; ≈ 13–15 MB
  at 1,000). Past ~500 clocks, consider adding a
  category filter or search box to `app.js` (keep the random order as the default).
- The harness snapshot dates are fixed (16 Oct 2026). Use `snap.mjs … id@HH:MM:SS@YYYY-MM-DD` for other dates; both
  `test.mjs` and `snap.mjs` take `--tz Europe/London` etc. for other locations (sun- and moon-based clocks use the
  viewer's approximate location, estimated from the time zone).
- `assemble.py` refuses a part whose first line isn't its marker or whose `defineClock({` calls don't all start with
  `id:` — these would otherwise break the count or the next split.
- Round 3's send-backs (18 of 140) were nearly all 140 px legibility: readings by counting (cribbage pegs, foosball
  beads, lamps, garments), small dials inside a scene (steam engine, tide predictor, ikebana), and digits made of many
  parts that did not read as digits (mines, four-colour map, WFC tiles). Look at the S sheet first and hardest.
- After assembling, grep the page for the old count in words (`two hundred and forty`): `assemble.py --auto` renames
  the title, wordmark and aria-label, but check that nothing else carries the old number.
